<!DOCTYPE html>
<html>
  
<head>
    <style>
      @media only screen and (max-width:620px) {
        /* For mobile phones: */
        .main-menu, #home, .home-picture, .buttonbox, .button, .search {
          width:100%;
        }
      }
    </style>

    <meta charset="utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0, shrink-to-fit=no">
    <title>Home</title>
     <script>
      alert("Selamat datang di mauer.id!");
     </script>
     <link rel="stylesheet" href="styles.css">
     <link rel="stylesheet" href="DropDown.css">
     <link rel="stylesheet" href="koneksi.php">
     <script src="js/jquery-3.6.0.min.js"></script>
     <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap-4.6.0-dist/css/bootstrap.min.css">
  
     <!-- CDN of Bootstrap -->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
     <!-- CDN of mark.js -->
     <script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js" integrity="sha512-5CYOlHXGh6QpOFA/TeTylKLWfB3ftPsde7AnmhuitiTX4K5SqCLBeKro6sPS8ilsz1Q4NRx3v8Ko2IBiszzdww==" crossorigin="anonymous">
     </script> 
     <!-- CDN of google font -->
     <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@500&display=swap');
     </style> 
</head>
  
<body>
    <header>
      <a href="index.php"><img src="img/mauerLogo.png" width="100px" height="65px" alt=""></a>
    </header>

    <nav>
      <table width="100%">
        <tr>
          <th><a href="index.php">Home</a></th>
          <th><a href="about-us.php">About Us</a></th>
          <th>
          <div class="navbutton">
            <a href="gallery.php">Gallery</a>
            <div class="dropdown-box">
              <div class="navbutton">
                <a href="phantasie.php">Phantasie</a>
              </div>
              <div class="navbutton">
                <a href="minimal.php">Minimal</a>
              </div>
              <div class="navbutton">
                <a href="silhouette.php">Silhouette</a>
              </div>
              <div class="navbutton">
                <a href="https://instagram.com/mauer.id" target="_blank">Custom</a>
              </div>
            </div>
          </div>
          </th>
          <th><a href="contact-us.php">Contact Us</a></th>
          <th>

          <form role="form" action="Index.php" method="get">
            <div class="container-fluid">
            <input type="text" size="30" 
                placeholder="search..." id="searched"
                style="border: 1px solid #0b2247; 
                        width:110px;height:30px;">

            <button type="button" class="btn-primary btn-sm mb-3" name="Search" 
                style="padding-left:10px;height:32px;width:60px;
                      background-color:#0b2247;
                      border:0px;" onclick="highlight('1');">
                        
                <i class="fa fa-search">Search</i>
            </button>
            </div>
          </form> 
          </th>
          <th><a href="Register.php">Register</a></th>
          <th><a href="Login.php">Login</a></th>
          <th><a href="logout.php" name="logout" class="logout" onClick="return confirm('Apakah anda yakin ingin keluar?')">Logout</a></th>
          </tr>
        </table>
    </nav>

    <br>
  
    <div class="main-menu">

      <aside class="home-picture">
        <img src="img/home-img.svg" width="400px" height="500px" alt="">
      </aside>

      <div class="container-fluid">
      <main id="home" class="select">
        <h1>Lagi Cari Design Wall Art yang Bagus? </h1>
        <p align="center">Anda tidak perlu bingung lagi untuk mencari Design Wall Art yang bagus. Disini kamu akan menemukan berbagai macam pilihan design-design Wall Art yang tentunya bakal cocok buat kamu. </p>
        <p>Decorate your wall with us!</p>
      <a href="https://instagram.com/mauer.id" target="_blank">
        <div class="buttonbox">
          <p>INFO LEBIH LANJUT</p>
        </div>
      </a>
      </main>
    </div>
    </div>

    <footer>
      <p><br>Kelompok 5 &copy; 2021 All Rights Reserved</p>
    </footer>

    <center><a href="https://www.instagram.com" target="blank"><img style="border-radius: 50%" src="image8.png" width="70px" height="50px"></a>
      <a href="https://www.facebook.com" target="blank"><img style="border-radius: 50%" src="image9.png" width="38px" height="38px"></a>
      <a href="https://twitter.com" target="blank"><img style="border-radius: 50%" src="image10.png" width="60px" height="60px"></a>
    </center>

      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap-4.6.0-dist/js/bootstrap.min.js"></script>
      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js"></script>  
  
    <script>
        function highlight(param) {
  
            // Select the whole paragraph
            var ob = new Mark(document.querySelector(".select"));
  
            // First unmark the highlighted word or letter
            ob.unmark();
  
            // Highlight letter or word
            ob.mark(
                document.getElementById("searched").value,
                { className: 'a' + param }
            );
        }
    </script>
</body> 
</html>