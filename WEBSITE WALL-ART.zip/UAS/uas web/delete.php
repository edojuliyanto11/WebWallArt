<?php 

    $conn = mysqli_connect('localhost', 'root','', 'wall art'); 
    $username = $_GET['username'];
    $sqlDelete = "DELETE FROM tb_user WHERE username='$username'";
    mysqli_query($conn, $sqlDelete);

    header("location: dashboard.php");
?>