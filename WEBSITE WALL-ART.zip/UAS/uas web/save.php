<?php
$koneksi = mysqli_connect('localhost', 'root', '', 'wall art');
$username = $_POST['username'];
$nama = $_POST['nama'];
$password = $_POST['password'];

if (empty($username && $nama && $password)) {
    echo '<script>alert("Mohon mengisi semua form yang tersedia, Terima kasih");window.location.href="tambah_user.php"</script>';
} else {
    $query = mysqli_query($koneksi, "UPDATE tb_user SET username='$username',nama='$nama',password='$password' WHERE id='$id'");
    echo '<script>alert("Data user berhasil diupdate, Terima kasih");window.location.href="dashboard.php"</script>';
}
?>