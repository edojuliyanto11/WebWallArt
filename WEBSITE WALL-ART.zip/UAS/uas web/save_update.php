<?php
$koneksi = mysqli_connect('localhost', 'root', '', 'wall art');
$username = $_POST['username'];
$password = $_POST['password'];
$nama = $_POST['nama'];
$email = $_POST['email'];


if (empty($username && $password && $nama && $email)) {
    echo '<script>alert("Mohon mengisi semua form yang tersedia, Terima kasih");window.location.href="update.php"</script>';
} else {
    $query = mysqli_query($koneksi, "UPDATE tb_user SET password='$password',nama='$nama',email='$email' WHERE username='$username'");
    echo '<script>alert("Data pegawai berhasil diupdate, Terima kasih");window.location.href="dashboard.php"</script>';
}
?>