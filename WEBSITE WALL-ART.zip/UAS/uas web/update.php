<?php 
    include 'database_connect.php';
    $conn = mysqli_connect('localhost', 'root','', 'wall art');
    $username = $_GET['username'];
    $sqlGet = "SELECT * FROM tb_user WHERE username='$username'";
    $queryGet = mysqli_query($conn,$sqlGet);
    $data = mysqli_fetch_array($queryGet);

    if(isset($_POST['Update'])){
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $nama = $_POST['nama'];
        $email = $_POST['email'];

        $database = new database;

        $sql = $database->edit($username,$password,$nama,$email);

        if ($sql) {
            echo '<script>alert("Berhasil menyimpan data.");
                document.location="dashboard.php";</script>';
        }else{
            echo '<div class="alert alert-warning">Gagal melakukan proses edit data.';
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data User</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>

<body>
    <div class="container-fluid p-3">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Update Data User</li>
                        </ol>
                    </nav>
                    <div class="card-body">
                        <form method="POST" action="update.php">
                        
                            <input type="text" class="form-control" id="username" name="username" value="<?= $data['username'] ?>" readonly >
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" value="<?= $data['password'] ?>" name="password" placeholder="Password anda..." required>
                            </div>
                            <div class="form-group">
                                <label for="nama">Nama User</label>
                                <input type="text" class="form-control" id="nama" value="<?= $data['nama'] ?>" name="nama" placeholder="Nama anda..." required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="text" class="form-control" id="email" value="<?= $data['email'] ?>" name="email" placeholder="Email anda..." required>
                            </div>
                            <button type="submit" name="Update" class="btn btn-secondary mb-3" style="font-family: 'Museo Sans Rounded 500', sans-serif; font-size: 16px;">Update User</button>
                            <button type="button" class="btn btn-danger mb-3" onclick="window.location.href='dashboard.php'" style="font-family: 'Museo Sans Rounded 500', sans-serif; font-size: 16px;">Batal</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</body>
</html>