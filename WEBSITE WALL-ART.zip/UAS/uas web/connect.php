<?php
	$conn = mysqli_connect('localhost', 'root','', 'wall art');
?>