<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data User</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>

<body>
    <div class="container-fluid p-3">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Tambah User</li>
                        </ol>
                    </nav>
                    <div class="card-body">
                        <button class="btn btn-secondary mb-3">Tambah User</button>
                        <form method="POST" action="save_tambahuser.php">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Username anda..." required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password anda..." required>
                            </div>
                            <div class="form-group">
                                <label for="nama">Nama User</label>
                                <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama anda..." required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="text" class="form-control" id="email" name="email" placeholder="Email anda..." required>
                            </div>
                            <button type="submit" class="btn btn-primary" name="simpan" style="font-family: 'Museo Sans Rounded 500', sans-serif; font-size: 16px;">Simpan</button>
                            <button type="button" class="btn btn-danger" onclick="window.location.href='dashboard.php'" style="font-family: 'Museo Sans Rounded 500', sans-serif; font-size: 16px;">Batal</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>