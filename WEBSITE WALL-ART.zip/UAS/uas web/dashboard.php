<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"/>
</head>

<body>
    <nav style="margin-top: 50px; margin-bottom: 20px;margin-left: 80px">
      <table width="100%">
        <tr>
          <th><a href="dashboard.php">Dashboard Admin- Data User</a></th>
          <th><a href="dashboard_contact.php">Dashboard Admin-Data Contact Us User</a></th>
          <th><a href="logout.php" name="logout" class="logout" onClick="return confirm('Apakah anda yakin ingin keluar?')">Logout</a></th>
        </tr>
      </table>
    </nav>
    <hr>
    
    <div class="container-fluid">
        <span class="text-center">
            <h1>Data User</h1>
            <h3>WALL ART MOUER</h3>
        </span>
        <div class="row">
            <div class="col-12 p-5">
                <div class="card">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb" style="border-bottom-left-radius: 0px; border-bottom-right-radius: 0px">
                            <li class="breadcrumb-item active" aria-current="page">Dashboard-Admin</li>
                        </ol>
                    </nav>
                    <div class="card-body">
                        <a href="tambah_user.php" class="btn btn-primary mb-3"><i class="fa fa-plus"></i>Tambah User</a>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">NOMOR<br>URUT</th>
                                    <th scope="col">USERNAME</th>
                                    <th scope="col">PASSWORD</th>
                                    <th scope="col">NAMA</th>
                                    <th scope="col">EMAIL</th>
                                    <th scope="col">UBAH</th>
                                    <th scope="col">HAPUS</th>
                                </tr>
                            </thead>
                            <?php
                            $koneksi = mysqli_connect('localhost', 'root', '', 'wall art');
                            $no = 1;
                            $view = mysqli_query($koneksi, "SELECT * FROM tb_user");
                            while ($data = mysqli_fetch_array($view)) {
                            ?>

                                <tbody>
                                    <tr <?php if ($no % 2 === 1)
                                            echo 'style="background-color: lightgray"';
                                        ?>>
                                        <th scope="row"><?= $no++ ?></th>
                                        <td><?= $data['username'] ?></td>
                                        <td><?= $data['password'] ?></td>
                                        <td><?= $data['nama'] ?></td>
                                        <td><?= $data['email'] ?></td>
                                        <td><a href="update.php?username=<?=$data['username']?>" class="btn btn-warning" name="Update"><i class="fa fa-edit"></i>Edit</a></td>
                                        <td><a href="delete.php?username=<?=$data['username']?>" class="btn btn-danger" name="Delete" ><i class="fa fa-trash"></i>Delete</a></td>
                                    </tr>
                                </tbody>
                            <?php } ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

