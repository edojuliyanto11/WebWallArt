<?php
	$koneksi = mysqli_connect('localhost', 'root', '', 'wall art');
	include_once('database_connect.php');
	$database = new database();
	if(isset($_POST['simpan']))
	{
	    $username = $_POST['username'];
	    $subjek = $_POST['subjek'];
	    $isi = $_POST['isi'];
	    if($database->simpan_contact($username,$subjek,$isi))
	    {
	      header('location:dashboard_contact.php');
	    }
	}

	if (empty($username && $subjek && $isi)) {
	    echo '<script>alert("Mohon mengisi semua form yang tersedia, Terima kasih");window.location.href="tambah_user_contact.php"</script>';
	} else {
	    $query = mysqli_query($koneksi, "INSERT INTO tb_contact VALUES (NULL, '$username','$isi','$subjek')");
	    echo '<script>alert("Data user berhasil ditambahkan, Terima kasih");window.location.href="dashboard_contact.php"</script>';
	}
?>
