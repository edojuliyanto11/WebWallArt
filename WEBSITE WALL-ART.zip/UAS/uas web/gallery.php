<!DOCTYPE html>
    <html lang="en" dir="ltr">

    <style>

    @media only screen and (max-width:620px) {
        /* For mobile phones: */
        .responsive {
          width:100%;
      }
    }
    </style>

    <head>
      <meta charset="utf-8">
      <meta name = "viewport" content = "width = device-width, initial-scale = 1.0, shrink-to-fit=no">
      <title>Gallery</title>
      <link rel="stylesheet" href="styles.css">
      <link rel="stylesheet" href="DropDown.css">
      <script src="js/jquery-3.6.0.min.js"></script>
      <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap-4.6.0-dist/css/bootstrap.min.css">
    <!-- CDN of Bootstrap -->
    <link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
        integrity=
"sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" 
        crossorigin="anonymous">
  
    <!-- CDN of mark.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js"
        integrity=
"sha512-5CYOlHXGh6QpOFA/TeTylKLWfB3ftPsde7AnmhuitiTX4K5SqCLBeKro6sPS8ilsz1Q4NRx3v8Ko2IBiszzdww=="
        crossorigin="anonymous">
    </script>
      
    <!-- CDN of google font -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@500&display=swap'
        );
    </style>

      <script>
        $(document).ready(function() {
          $("#nav li").hover(function() {
            $(this).find("ul").slideToggle("fast");
        });
      });
      </script>
    </head>

    <body>

      <header>
          <a href="index.html"><img src="img/mauerLogo.png" width="100px" height="65px" alt=""></a>
      </header>

    <nav>
      <table width="100%">
        <tr>
          <th><a href="index.php">Home</a></th>
          <th><a href="about-us.php">About Us</a></th>
          <th>
          <div class="navbutton">
            <a href="gallery.php">Gallery</a>
            <div class="dropdown-box">
              <div class="navbutton">
                <a href="phantasie.php">Phantasie</a>
              </div>
              <div class="navbutton">
                <a href="minimal.php">Minimal</a>
              </div>
              <div class="navbutton">
                <a href="silhouette.php">Silhouette</a>
              </div>
              <div class="navbutton">
                <a href="https://instagram.com/mauer.id" target="_blank">Custom</a>
              </div>
            </div>
          </div>
          </th>
          <th><a href="contact-us.php">Contact Us</a></th>
          <th>
          <form role="form" action="contact-us.php" method="get">
            <div class="container-fluid">
            <input type="text" size="30" 
                placeholder="search..." id="searched"
                style="border: 1px solid #0b2247; 
                        width:110px;height:30px;">

            <button type="button" class="btn-primary btn-sm" name="Search" 
                style="padding-left:10px;height:32px;width:60px;
                      background-color:#0b2247;
                      border:0px;" onclick="highlight('1');">
                        
                <i class="fa fa-search">Search</i>
            </button>
            </div>
          </form> 
          </th>
          <th><a href="register.php">Register</a></th>
          <th><a href="login.php">Login</a></th>
          <th><a href="logout.php" name="logout" class="logout" onClick="return confirm('Apakah anda yakin ingin keluar?')">Logout</a></th>
          </tr>
        </table>
    </nav>
    <br>
    </div>
      <main id="gallery" class="select">
        <br><br>
        <h1>Phantasie</h1>
        <p>Artwork by @brlmk</p>
        <div class="container">
          <div class="box">
            <img src="img/1a.jpg" width="100%" height="80%" alt="">
            <p>The Long Overdue</p>
          </div>

          <div class="box">
            <img src="img/2a.jpg" width="100%" height="80%" alt="">
            <p>Whipped!</p>
          </div>

          <div class="box">
            <img src="img/3.jpg" width="100%" height="80%" alt="">
            <p>Pantone</p>
          </div>

          <div class="box">
            <img src="img/1.jpg" width="100%" height="80%" alt="">
            <p>Familiar</p>
          </div>

          <div class="box">
            <img src="img/5a.jpg" width="100%" height="80%" alt="">

            <p>Lily</p>
          </div>

          <div class="box">
            <img src="img/2.jpg" width="100%" height="80%" alt="">
            <p>A Quiet Place</p>
          </div>

          <div class="box">
            <img src="img/6.jpg" width="100%" height="80%" alt="">
            <p>L'ultima Volta</p>
          </div>

          <div class="box">
            <img src="img/5.jpg" width="100%" height="80%" alt="">
            <p>AHA!</p>
          </div>

          <div class="box">
            <img src="img/4.jpg" width="100%" height="80%" alt="">
            <p>Innocence Lost</p>
          </div>
        </div>

        <br><br>
        <h1>Minimal</h1>
        <p>Artwork by @isaiah.vallentino</p>

        <div class="container">
          <div class="box">
            <img src="img/11.jpg" width="100%" height="80%" alt="">
            <p>Sand Adventure</p>
          </div>

          <div class="box">
            <img src="img/7.jpg" width="100%" height="80%" alt="">
            <p>Sunset Sea</p>
          </div>

          <div class="box">
            <img src="img/9.jpg" width="100%" height="80%" alt="">
            <p>Moon Siblings</p>
          </div>

          <div class="box">
            <img src="img/10.jpg" width="100%" height="80%" alt="">
            <p>Sunnyside</p>
          </div>

          <div class="box">
            <img src="img/12.jpg" width="100%" height="80%" alt="">
            <p>Autumn Vibes</p>
          </div>

          <div class="box">
            <img src="img/16.jpg" width="100%" height="80%" alt="">
            <p>Monogram</p>
          </div>

          <div class="box">
            <img src="img/17.jpg" width="100%" height="80%" alt="">
            <p>Overseas</p>
          </div>

          <div class="box">
            <img src="img/22.jpg" width="100%" height="80%" alt="">
            <p>Moon Evolution</p>
          </div>

          <div class="box">
            <img src="img/23.jpg" width="100%" height="80%" alt="">
            <p>Fountain</p>
          </div>
        </div>

        <br><br>
        <h1>Silhouette</h1>
        <p>Artwork by @delvink5</p>

        <div class="container">
          <div class="box">
            <img src="img/13.jpg" width="100%" height="80%" alt="">
            <p>Eucalyptus</p>
          </div>

          <div class="box">
            <img src="img/14.jpg" width="100%" height="80%" alt="">
            <p>Bonsai</p>
          </div>

          <div class="box">
            <img src="img/15.jpg" width="100%" height="80%" alt="">
            <p>Golden Springs</p>
          </div>

          <div class="box">
            <img src="img/18.jpg" width="100%" height="80%" alt="">
            <p>Dawn</p>
          </div>

          <div class="box">
            <img src="img/19.jpg" width="100%" height="80%" alt="">
            <p>Monstera</p>
          </div>

          <div class="box">
            <img src="img/20.jpg" width="100%" height="80%" alt="">
            <p>Night Wild</p>
          </div>

          <div class="box">
            <img src="img/21.jpg" width="100%" height="80%" alt="">
            <p>The Harvest</p>
          </div>
        </div>
      </main>

     <footer>
        <p><br>Kelompok 5 &copy; 2021 All Rights Reserved</p>
      </footer>

      <center><a href="https://www.instagram.com" target="blank"><img style="border-radius: 50%" src="image8.png" width="70px" height="50px"></a>
      <a href="https://www.facebook.com" target="blank"><img style="border-radius: 50%" src="image9.png" width="38px" height="38px"></a>
        <a href="https://twitter.com" target="blank"><img style="border-radius: 50%" src="image10.png" width="60px" height="60px"></a>
      </center>

    <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.min.js"></script>
    <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function highlight(param) {
  
            // Select the whole paragraph
            var ob = new Mark(document.querySelector(".select"));
  
            // First unmark the highlighted word or letter
            ob.unmark();
  
            // Highlight letter or word
            ob.mark(
                document.getElementById("searched").value,
                { className: 'a' + param }
            );
        }
    </script>
  </body>
</html>
