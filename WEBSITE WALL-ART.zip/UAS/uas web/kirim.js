function send(){
	var con = confirm("kirim data?");
	if (con==true){
		alert("data terkirim");
	}
}