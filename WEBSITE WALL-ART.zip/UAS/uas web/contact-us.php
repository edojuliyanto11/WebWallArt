<?php 
  session_start();
  include_once('database_connect.php');
  $database = new database();
  if(isset($_POST['kirim']))
  {
      $username = $_SESSION['username'];
      $subjek = $_POST['subjek'];
      $isi = $_POST['isi'];
      if($database->kirim($username,$subjek,$isi))
      {
        header('location:contact-us.php');
      }
  } 
if(isset($_SESSION['username'])){
  $database = new database();
  $database->__construct();
  $username  = $_SESSION['username'];

  //membuat variabel $id untuk menyimpan id dari GET id di URL

  $select = $database->cekuser($username);

  //jika hasil query = 0 maka muncul pesan error
  if(mysqli_num_rows($select) == 0){
    echo '<div class="alert alert-warning">Username tidak ada dalam database.</div>';
    exit();
  //jika hasil query > 0
  }else{
    //membuat variabel $data dan menyimpan data row dari query
    $data = mysqli_fetch_assoc($select);
  }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<style>
  @media only screen and (max-width:620px) {
    /* For mobile phones: */
    .button, .search {
    width:100%;
    }
}
</style>

  <head>
    <meta charset="utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0, shrink-to-fit=no">
    <title>Contact Us</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="DropDown.css">
    <script src="js/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap-4.6.0-dist/css/bootstrap.min.css">
    <script src="kirim.js"></script>
    <link rel="stylesheet" href="koneksi.php">
    <!-- CDN of Bootstrap -->
    <link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
        integrity=
"sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" 
        crossorigin="anonymous">
  
    <!-- CDN of mark.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js"
        integrity=
"sha512-5CYOlHXGh6QpOFA/TeTylKLWfB3ftPsde7AnmhuitiTX4K5SqCLBeKro6sPS8ilsz1Q4NRx3v8Ko2IBiszzdww=="
        crossorigin="anonymous">
    </script>
      
    <!-- CDN of google font -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@500&display=swap'
        );
    </style>

    <script type="text/javascript">
    function eraseText() {
     document.getElementById("subjek").value = "";
     document.getElementById("isi").value = "";
     var con = confirm("apakah anda yakin untuk menghapus?");
        if (con==true){
          alert("pesan terhapus");
      }
    }
    </script>

  </head>

  <body>
      <header>
        <a href="index.php"><img src="img/mauerLogo.png" width="100px" height="65px" alt=""></a>
      </header>

    <nav>
      <table width="100%">
        <tr>
          <th><a href="index.php">Home</a></th>
          <th><a href="about-us.php">About Us</a></th>
          <th>
          <div class="navbutton">
            <a href="gallery.php">Gallery</a>
            <div class="dropdown-box">
              <div class="navbutton">
                <a href="phantasie.php">Phantasie</a>
              </div>
              <div class="navbutton">
                <a href="minimal.php">Minimal</a>
              </div>
              <div class="navbutton">
                <a href="silhouette.php">Silhouette</a>
              </div>
              <div class="navbutton">
                <a href="https://instagram.com/mauer.id" target="_blank">Custom</a>
              </div>
            </div>
          </div>
          </th>
          <th><a href="contact-us.php">Contact Us</a></th>
          <th>
          <form role="form" action="contact-us.php" method="get">
            <div class="container-fluid">
            <input type="text" size="30" 
                placeholder="search..." id="searched"
                style="border: 1px solid #0b2247; 
                        width:110px;height:30px;">

            <button type="button" class="btn-primary btn-sm" name="Search" 
                style="padding-left:10px;height:32px;width:60px;
                      background-color:#0b2247;
                      border:0px;" onclick="highlight('1');">
                        
                <i class="fa fa-search">Search</i>
            </button>
            </div>
          </form> 
          </th>
          <th><a href="register.php">Register</a></th>
          <th><a href="login.php">Login</a></th>
          <th><a href="logout.php" name="logout" class="logout" onClick="return confirm('Apakah anda yakin ingin keluar?')">Logout</a></th>
          </tr>
        </table>
    </nav>
    <br>
    <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
      <div class="container-fluid">
      <main id="home" class="select">
       <br>
       <h1>Punya Pertanyaan?</h1>
       <p>Tulis pertanyaan kamu disini.</p>
       <br>
       <div class="form-group">
            <label for="nama"><b>Username</b></label>
            <input class="form-control" id="nama" name="username" placeholder="Username Anda..." value="<?php echo "$data[username]"; ?>">
       </div>
        <div class="form-group">
            <label for="subjek"><b>Subjek</b></label>
            <input class="form-control" id="subjek" name="subjek" placeholder="Subjek:">
        </div>
        <div class="form-group">
            <label for="pesan"><b>Pesan</b></label>
            <textarea id="isi" name="isi" class="form-control" style="height: 300px" placeholder="Tulis pertanyaanmu disini..."></textarea>
        </div>
        <br>

        <button type="submit" name="kirim" class="btn btn-primary" onClick="return confirm('Apakah anda yakin untuk mengirim?')">Kirim</button>
        <input type="button" class="btn btn-danger" name="clear" onclick="javascript:eraseText();" value="Clear">
      </main>
    </div>
    </form>

   <footer>
      <p><br>Kelompok 5 &copy; 2021 All Rights Reserved</p>
    </footer>

    <center><a href="https://www.instagram.com" target="blank"><img style="border-radius: 50%" src="image8.png" width="70px" height="50px"></a>
    <a href="https://www.facebook.com" target="blank"><img style="border-radius: 50%" src="image9.png" width="38px" height="38px"></a>
      <a href="https://twitter.com" target="blank"><img style="border-radius: 50%" src="image10.png" width="60px" height="60px"></a>
    </center>

      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.min.js"></script>
      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function highlight(param) {
  
            // Select the whole paragraph
            var ob = new Mark(document.querySelector(".select"));
  
            // First unmark the highlighted word or letter
            ob.unmark();
  
            // Highlight letter or word
            ob.mark(
                document.getElementById("searched").value,
                { className: 'a' + param }
            );
        }
    </script>
  </body>
</html>
