    function eraseText() {
     document.getElementById("output").value = "";
     document.getElementById("Nama").value = "";
     document.getElementById("Email").value = "";
     document.getElementById("Negara").value = "";
     document.getElementById("Subjek").value = "";
	}