<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Contact</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>

<body>
    <div class="container-fluid p-3">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard_contact.php">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Tambah Contact</li>
                        </ol>
                    </nav>
                    <div class="card-body">
                        <button class="btn btn-secondary mb-3">Tambah</button>
                        <form method="POST" action="save_tambahuser_contact.php">
                            <div class="form-group">
                                <label for="nama">Username (*Isi dengan username anda yang telah terdaftar)</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Username anda..." required>
                            </div>
                            <div class="form-group">
                                <label for="subjek">Subjek</label>
                                <input type="text" class="form-control" id="subjek" name="subjek" placeholder="Subjek..." required>
                            </div>
                           <div class="form-group">
                                <label for="isi">Pesan</label>
                                <textarea type="text" class="form-control" style="height: 300px" id="isi" name="isi" placeholder="Ketik pertanyaan anda disini..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary" name="simpan" style="font-family: 'Museo Sans Rounded 500', sans-serif; font-size: 16px;">Simpan</button>
                            <button type="button" class="btn btn-danger" onclick="window.location.href='dashboard_contact.php'" style="font-family: 'Museo Sans Rounded 500', sans-serif; font-size: 16px;">Batal</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>