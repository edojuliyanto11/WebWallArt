<?php
	$koneksi = mysqli_connect('localhost', 'root', '', 'wall art');
	$username = $_POST['username'];
	$subjek = $_POST['subjek'];
	$isi = $_POST['isi'];

	if (empty($username && $subjek && $isi)) {
	    echo '<script>alert("Mohon mengisi semua form yang tersedia, Terima kasih");window.location.href="update_contact.php"</script>';
	} else {
	    $query = mysqli_query($koneksi, "UPDATE tb_contact SET subjek='$subjek', isi='$isi' WHERE username='$username'");
	    echo '<script>alert("Data pegawai berhasil diupdate, Terima kasih");window.location.href="dashboard_contact.php"</script>';
	}
?>