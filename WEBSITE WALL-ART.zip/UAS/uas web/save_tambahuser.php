<?php
include_once('database_connect.php');
$database = new database();
if(isset($_POST['simpan']))
{
    $username = $_POST['username'];
    $password = password_hash($_POST['password'],PASSWORD_DEFAULT);
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    if($database->simpan_user($username,$password,$nama,$email))
    {
      header('location:dashboard.php');
    }
}

if (empty($username && $password && $nama && $email)) {
    echo '<script>alert("Mohon mengisi semua form yang tersedia, Terima kasih");window.location.href="tambah_user.php"</script>';
} else {
    $query = mysqli_query($koneksi, "INSERT INTO tb_user VALUES (NULL, '$username','$password','$nama','$email')");
    echo '<script>alert("Data user berhasil ditambahkan, Terima kasih");window.location.href="dashboard.php"</script>';
}
?>
