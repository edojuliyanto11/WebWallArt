<?php 
    include 'database_connect.php';
    $conn = mysqli_connect('localhost', 'root','', 'wall art');
    $username = $_GET['username'];
    $sqlGet = "SELECT * FROM tb_contact WHERE username='$username'";
    $queryGet = mysqli_query($conn,$sqlGet);
    $data = mysqli_fetch_array($queryGet);

    if(isset($_POST['Update'])){
        $username = $_POST['username'];
        $subjek = $_POST['subjek'];
        $isi = $_POST['isi'];

        $database = new database;

        $sql = $database->edit_contact($username,$subjek,$isi);

        if ($sql) {
            echo '<script>alert("Berhasil menyimpan data.");
                document.location="dashboard_contact.php";</script>';
        }else{
            echo '<div class="alert alert-warning">Gagal melakukan proses edit data.';
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data Contact</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>

<body>
    <div class="container-fluid p-3">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard_contact.php">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Update Data Contact</li>
                        </ol>
                    </nav>
                    <div class="card-body">
                        <form method="POST" action="update_contact.php">
                        
                            <input type="text" class="form-control" id="username" name="username" value="<?= $data['username'] ?>" readonly >
                            <div class="form-group">
                                <label for="subjek">Subjek</label>
                                <input type="text" class="form-control" id="subjek" value="<?= $data['subjek'] ?>" name="subjek" placeholder="Subjek..." required>
                            </div>
                            <div class="form-group">
                                <label for="isi">Pesan</label>
                                <input type="text" class="form-control" id="isi" value="<?= $data['isi'] ?>" name="isi" placeholder="Ketik pertanyaan anda disini..." required>
                            </div>
                            <button type="submit" name="Update" class="btn btn-secondary mb-3">Update</button>
                            <button type="button" class="btn btn-danger mb-3" onclick="window.location.href='dashboard_contact.php'">Batal</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</body>
</html>