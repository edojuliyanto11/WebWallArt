<script>
    function highlight(param) {
  
    	// Select the whole paragraph
        var ob = new Mark(document.querySelector(".select"));
  
        // First unmark the highlighted word or letter
        ob.unmark();
  
        // Highlight letter or word
        ob.mark(
            document.getElementById("searched").value,
            { className: 'a' + param }
        );
    }
</script>