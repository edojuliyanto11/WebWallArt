<?php
include("db.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
$nama=mysql_real_escape_string($_POST['nama']);
$email=mysql_real_escape_string($_POST['email']);
$pesan=mysql_real_escape_string($_POST['pesan']);
if(strlen($nama)>0 && strlen($email)>0 && strlen($pesan)>0)
{
$waktu=time();
mysql_query("INSERT INTO contact (nama,email,pesan,tanggal) VALUES('$nama','$email','$pesan','$waktu')");
echo "<h1>Terima Kasih!</h1>";
}
}
?>