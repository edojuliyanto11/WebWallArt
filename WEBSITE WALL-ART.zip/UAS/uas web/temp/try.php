<!DOCTYPE html>
<html lang="en" dir="ltr">
	
	<head>
		<style>
	      .highlight{
	        background-color: yellow;
	      }
        </style>

        <script type="text/javascript">
			function highlight(element, string, search, originalString){
			if(search.length > 0){
			let rengex = new RegExp(search, "g");
			newString = string.replace(regex, "<span class='highlight'>" + search + "</span")
			element.innerHTML = newString;
			}else{
				element.innerHTML = originalString;
			}
		  }

		  const content = document.getElementById("content");
		  const searchInput = document.getElementById("searchInput");
		  const searchBtn = document.getElementById("searchBtn");

		  //persiapan kalau tidak mau mencari apapun
		  let originalContent = content.innerText

		  //jalankan ketika klik button search
		  searchBtn.addEventListener("click", function(){
		  	highlight(content, content.innerText, searchInput.value, originalContent)
		  });
        </script>

        <link rel="stylesheet" href="search.js">
	    <script src="js/jquery-3.6.0.min.js"></script>
	    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap-4.6.0-dist/css/bootstrap.min.css">
	</head>

	<body>
     <input type="text" name="search" placeholder="search..." id="searchInput" />              
   	 <button type="submit" class="btn btn-primary" id="searchBtn">Search</button>

   	 <div id="content">
   	 Semua orang bisa menjadi programmer.	
   	 </div>
   	</body>