<!DOCTYPE html>
<html lang="en" dir="ltr">

  <head>
    <style>
      @media only screen and (max-width:620px) {
        /* For mobile phones: */
        .main-menu, #home, .home-picture, .buttonbox, .button, .search {
          width:100%;
        }
      }
    </style>

    <meta charset="utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0, shrink-to-fit=no">
    <title>Home</title>
     <script>
      alert("Selamat datang di mauer.id!");
     </script>
     <link rel="stylesheet" href="styles.css">
     <link rel="stylesheet" href="DropDown.css">
     <link rel="stylesheet" href="koneksi.php">
     <link rel="stylesheet" href="search.js">
     <script src="js/jquery-3.6.0.min.js"></script>
     <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap-4.6.0-dist/css/bootstrap.min.css">
      <!-- CDN of fontawsome -->
      <link rel="stylesheet" href=
    "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

      <!-- CDN of Bootstrap -->
      <link rel="stylesheet" href=
    "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
        integrity=
    "sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ"
        crossorigin="anonymous">

      <!-- CDN of mark.js -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js"
        integrity=
    "sha512-5CYOlHXGh6QpOFA/TeTylKLWfB3ftPsde7AnmhuitiTX4K5SqCLBeKro6sPS8ilsz1Q4NRx3v8Ko2IBiszzdww=="
        crossorigin="anonymous">
      </script>
      
      <!-- CDN of google font -->
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@500&display=swap'
        );
      </style>
  </head>

  <body>

    <header>
      <a href="index.html"><img src="img/mauerLogo.png" width="100px" height="65px" alt=""></a>
    </header>

    <nav>
      <table width="100%">
        <tr>
          <th><a href="index.php">Home</a></th>
          <th><a href="about-us.php">About Us</a></th>
          <th>
          <div class="navbutton">
            <a href="gallery.php">Gallery</a>
            <div class="dropdown-box">
              <div class="navbutton">
                <a href="phantasie.php">Phantasie</a>
              </div>
              <div class="navbutton">
                <a href="minimal.php">Minimal</a>
              </div>
              <div class="navbutton">
                <a href="silhouette.php">Silhouette</a>
              </div>
              <div class="navbutton">
                <a href="https://instagram.com/mauer.id" target="_blank">Custom</a>
              </div>
            </div>
          </div>
          </th>
          <th><a href="contact-us.php">Contact Us</a></th>
          <th>
         <div class="row">
          <div class="col-sm-4">
          <form role="form" action="index.php" method="get">
           <div class="form-group">
            <div class="container-fluid">
           <label>Cari</label>
           <input type="text" placeholder="search..." id="searched" size="30" /
                  style="border: 1px solid green;
                  width:300px;height:30px;">     
            </div>
           </div>
          <button type="button" name="search" class="btn-primary btn-sm mb-3"
                  style="margin-left:-5px;height:32px;width:70px;
                  background-color:rgb(12, 138, 12);
                  border:0px;" onclick="highlight('0');">

          <i class="fa fa-search"></i>
          </button>
          </form> 
          </div>
         </div>
          </th>
          <th><a href="register.php">Register</a></th>
          <th><a href="login.php">Login</a></th>
          <th><a href="logout.php">Logout</a></th>
          </tr>
        </table>
    </nav>

    <br><br>         
    <div align="center">
      <div>
          <b><i>Choose the color of highlighter:</i></b>
      </div>
      <br>
      <div style="background-color: cyan;
          width: 20px; height: 20px;
          display: inline-block; margin-left: -30px;"
          onmouseover="highlight('1')">
      </div>

      <div style="background-color: red;
          width: 20px; height: 20px;
          display: inline-block; margin-left: 10px;"
          onmouseover="highlight('2')">
      </div>

      <div style="background-color: green;
          width: 20px; height: 20px;
          display: inline-block; margin-left: 10px;"
          onmouseover="highlight('3')">
      </div>

      <div style="background-color: pink;
          width: 20px; height: 20px;
          display: inline-block; margin-left: 10px;"
          onmouseover="highlight('4')">
      </div>
    </div>
  
    <div class="main-menu">

      <aside class="home-picture">
        <img src="img/home-img.svg" width="400px" height="500px" alt="">
      </aside>

    <div class="container-fluid" style=
      "padding-left: 30%; padding-right: 30%;
      padding-top: 5%;">
      <main id="home" class="select">
        <h1>Lagi Cari Design Wall Art yang Bagus? </h1>
        <p align="center">Anda tidak perlu bingung lagi untuk mencari Design Wall Art yang bagus. Disini kamu akan menemukan berbagai macam pilihan design-design Wall Art yang tentunya bakal cocok buat kamu. </p>
        <p>Decorate your wall with us!</p>
      <a href="https://instagram.com/mauer.id" target="_blank">
        <div class="buttonbox">
          <p>INFO LEBIH LANJUT</p>
        </div>
      </a>
      </main>
    </div>
    </div>

    <footer>
      <p><br>Kelompok 5 &copy; 2021 All Rights Reserved</p>
    </footer>

    <center><a href="https://www.instagram.com" target="blank"><img style="border-radius: 50%" src="image8.png" width="70px" height="50px"></a>
      <a href="https://www.facebook.com" target="blank"><img style="border-radius: 50%" src="image9.png" width="38px" height="38px"></a>
      <a href="https://twitter.com" target="blank"><img style="border-radius: 50%" src="image10.png" width="60px" height="60px"></a>
    </center>

      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap-4.6.0-dist/js/bootstrap.min.js"></script>
      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js"></script>

      <script>
        function highlight(param) {

        // Select the whole paragraph
        var ob = new Mark(document.querySelector(".select"));

        // First unmark the highlighted word or letter
        ob.unmark();

        // Highlight letter or word
        ob.mark(
        document.getElementById("searched").value,
        { className: 'a' + param }
        );
      }
      </script>
  </body>
</html>
