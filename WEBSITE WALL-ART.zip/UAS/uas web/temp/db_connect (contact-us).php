<?php 
class database{
	var $host = "localhost";
	var $username = "root";
	var $password = "";
	var $database = "wall art";
	var $koneksi;
 
	function __construct(){
		$this->koneksi = mysqli_connect($this->host, $this->username, $this->password,$this->database);
	}
 
	function kirim($Nama,$Email,$Negara,$Subjek)
	{	
		$insert = mysqli_query($this->koneksi,"insert into contact_us values ('','$Nama','$Email','$Negara','$Subjek')");
		return $insert;
	}	
} 
?>
