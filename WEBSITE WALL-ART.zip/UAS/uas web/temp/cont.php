<script type="text/javascript" src="js/jquery.js"></script> 
<script type="text/javascript" src="js/jquery.validate.js"></script> 
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript">
$('document').ready(function(){
$('#form').validate({
rules:{
"nama":{
required:true,
maxlength:40
},
"email":{
required:true,
email:true,
maxlength:100
},
"pesan":{
required:true
}},
//Untuk menampilkan pesan apabila form tidak diisi
messages:{
"nama":{
required:"Mohon diisi"
},
"email":{
required:"Mohon diisi",
email:"Masukkan alamat email yang benar"
},
"pesan":{
required:"Mohon diisi"
}},
submitHandler: function(form){
$(form).ajaxSubmit({
target: '#tampilanform', 
success: function() { 
$('#kotakform').slideUp('fast'); 
} 
}); 
}
})
});
</script>
<div id="kotakform">
   <form id="form" action="submit.php" method="post">
      Nama
      <input type="text" name="nama" />
      Email
      <input type="text" name="email" />
      Pesan
      <textarea name="pesan"></textarea>
      <input type="submit" value="Kirim">
   </form>
</div>