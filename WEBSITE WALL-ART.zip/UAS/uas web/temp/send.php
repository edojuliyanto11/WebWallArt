fputs($smtpConnect, 'HELO '.$localhost . $newLine);
$response = fgets($smtpConnect, 465);
if($secure == 'tls')
{
    fputs($smtpConnect, 'STARTTLS'.$newLine);
    $response = fgets($smtpConnect, 465);
stream_socket_enable_crypto($smtpConnect, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);

// Say hello again!
    fputs($smtpConnect, 'HELO '.$localhost . $newLine);
    $response = fgets($smtpConnect, 465);
}