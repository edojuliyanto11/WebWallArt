<?php
	$autoload['libraries'] = array('database', 'session');
?>