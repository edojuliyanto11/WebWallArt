<?php 
class database{
	var $host = "localhost";
	var $username = "root";
	var $password = "";
	var $database = "wall art";
	var $koneksi;
 
	function __construct(){
		$this->koneksi = mysqli_connect($this->host, $this->username, $this->password,$this->database);
	}
 
 
	function register($username,$password,$nama,$email)
	{	
		$insert = mysqli_query($this->koneksi,"insert into tb_user values ('$username','$password','$nama','$email')");
		return $insert;
	}
 
	function login($username,$password,$remember)
	{
		$query = mysqli_query($this->koneksi,"select * from tb_user where username='$username'");
		$data_user = $query->fetch_array();
		if(password_verify($password,$data_user['password']))
		{
			
			if($remember)
			{
				setcookie('username', $username, time() + (60 * 60 * 24 * 5), '/');
				setcookie('nama', $data_user['nama'], time() + (60 * 60 * 24 * 5), '/');
			}
			$_SESSION['username'] = $username;
			$_SESSION['nama'] = $data_user['nama'];
			$_SESSION['is_login'] = TRUE;
			return TRUE;
		}
	}
 
	function relogin($username)
	{
		$query = mysqli_query($this->koneksi,"select * from tb_user where username='$username'");
		$data_user = $query->fetch_array();
		$_SESSION['username'] = $username;
		$_SESSION['nama'] = $data_user['nama'];
		$_SESSION['is_login'] = TRUE;
	}	

	function kirim($username,$subjek,$isi)
	{	
		$insert = mysqli_query($this->koneksi,"insert into tb_contact values ('$username','$subjek','$isi')");
		return $insert;
	}

	function delete($username)
	{
		$delete = mysqli_query($this->koneksi, "DELETE FROM tb_user WHERE username='$username'");
		return $delete;
	}

	function edit($username,$password,$nama,$email)
	{
		$edit = mysqli_query($this->koneksi, "UPDATE tb_user SET password='$password', nama='$nama', email='$email' WHERE username='$username'");
		return $edit;
	}

	function edit_contact($username,$subjek,$isi)
	{
		$edit_con = mysqli_query($this->koneksi, "UPDATE tb_contact SET subjek='$subjek', isi='$isi' WHERE username='$username'");
		return $edit_con;
	}

	function cekuser($username)
	{
		$cek = mysqli_query($this->koneksi,"select * from tb_user where username='$username'");
		return $cek;
	}

	function simpan_user($username,$password,$nama,$email)
	{	
		$insert = mysqli_query($this->koneksi,"insert into tb_user values ('$username','$password','$nama','$email')");
		return $insert;
	}

	function simpan_contact($username,$subjek,$isi)
	{	
		$insert = mysqli_query($this->koneksi,"insert into tb_contact values ('$username','$subjek','$isi')");
		return $insert;
	}
} 
?>
