<!DOCTYPE html>
<html lang="en" dir="ltr">

  <head>
    <style>

      @media only screen and (max-width:620px) {
        /* For mobile phones: */
        .main-menu, #home, .home-picture, .buttonbox, .button, .search {
          width:100%;
        }
      }
    </style>

    <meta charset="utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0, shrink-to-fit=no">
    <title>About Us</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="DropDown.css">
    <script src="js/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap-4.6.0-dist/css/bootstrap.min.css">
    <!-- CDN of Bootstrap -->
    <link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
        integrity=
"sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" 
        crossorigin="anonymous">
  
    <!-- CDN of mark.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js"
        integrity=
"sha512-5CYOlHXGh6QpOFA/TeTylKLWfB3ftPsde7AnmhuitiTX4K5SqCLBeKro6sPS8ilsz1Q4NRx3v8Ko2IBiszzdww=="
        crossorigin="anonymous">
    </script>
      
    <!-- CDN of google font -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@500&display=swap'
        );
    </style>

  </head>

  <body>

      <header>
        <a href="index.html"><img src="img/mauerLogo.png" width="100px" height="65px" alt=""></a>
      </header>

    <nav>
      <table width="100%">
        <tr>
          <th><a href="index.php">Home</a></th>
          <th><a href="about-us.php">About Us</a></th>
          <th>
          <div class="navbutton">
            <a href="gallery.php">Gallery</a>
            <div class="dropdown-box">
              <div class="navbutton">
                <a href="phantasie.php">Phantasie</a>
              </div>
              <div class="navbutton">
                <a href="minimal.php">Minimal</a>
              </div>
              <div class="navbutton">
                <a href="silhouette.php">Silhouette</a>
              </div>
              <div class="navbutton">
                <a href="https://instagram.com/mauer.id" target="_blank">Custom</a>
              </div>
            </div>
          </div>
          </th>
          <th><a href="contact-us.php">Contact Us</a></th>
          <th>
          <form role="form" action="" method="get">
            <div class="container-fluid">
            <input type="text" size="30" 
                placeholder="search..." id="searched"
                style="border: 1px solid #0b2247; 
                        width:110px;height:30px;">

            <button type="button" class="btn-primary btn-sm" name="Search" 
                style="padding-left:10px;height:32px;width:60px;
                      background-color:#0b2247;
                      border:0px;" onclick="highlight('1');">
                        
                <i class="fa fa-search">Search</i>
            </button>
            </div>
          </form> 
          </th>
          <th><a href="register.php">Register</a></th>
          <th><a href="login.php">Login</a></th>
          <th><a href="logout.php" name="logout" class="logout" onClick="return confirm('Apakah anda yakin ingin keluar?')">Logout</a></th>
          </tr>
        </table>
    </nav>

    <br>

    <main class="select">
    <div class="container">
      <p>
         <br><br>Mauer.id adalah jawaban buat kalian yang ingin mempercantik interior ruangan secara praktis. Metode yang termasuk digital printing ini menghasilkan produk bermutu. Wall art saat ini menjadi pilihan banyak orang untuk mempercantik interior ruangan rumahnya. Metode wall art prints ini dapat dilakukan secara digital yang memungkinkan custom graphic sehingga dapat disesuaikan dengan ukuran ruangan. Pengaplikasiannya juga dirancang sejalan gaya dekorasi ruangan tersebut sebelumnya dan tetap dibuat sesuai fungsi.
         <br><br>
         Seiring tren perkembangan desain interior, penggunaan wall art decor semacam ini menjadi semakin populer. Pasalnya, metode ini dianggap sebagai elemen dekoratif tambahan yang praktis untuk diaplikasikan pada dinding interior ruangan.
         <br><br>
        Website E-Katalog Wall-Art merupakan website yang bergerak di bidang seni khususnya Wall-Art Design. Website E-Katalog Wall-Art didirikan oleh 3 Mahasiswa yang sedang mengenyam pendidikannya di Universitas Bunda Mulia, jurusan Teknik Informatika semester 4. Dibentuk karena keinginan untuk mengenalkan berbagai macam design Wall-Art tidak hanya sebagai sebuah lukisan, namun juga sebagai seni.<br><br>
      </p>
    </div>

    <h1 style="font-family: 'Kraskario', serif"><b><center>Kelompok 5</center></b></h1>
    <br>

    <div class="container">
      <div class="box">
      <center><img style="border-radius: 50%" src="img/image33.png" width="250" height="250"></center>
        <h3><center>Edo Juliyanto</center></h3>
          <p>
            Saya adalah Mahasiswa aktif Universitas Bunda Mulia semester 4. Disini saya sebagai pembuat dari website ini. Semoga pengunjung website disini menyukai website yang telah kami buat, baik dari segi design dan informasi yang terdapat didalam website ini.
          </p>
        </div>
      <div class="box">
      <center><img style="border-radius: 50%" src="img/image31.jpeg" width="250" height="250"></center>
        <h3><center>Liza Angeline</center></h3>
          <p>
            Saya adalah Mahasiswi aktif Semester 4 di Universitas Bunda Mulia. Disini saya sebagai salah satu pembuat dari website ini. Saya berharap website ini bermanfaat untuk menambah wawasan dan inspirasi anda terhadap wall art.
          </p>
      </div>
      <div class="box">
      <center><img style="border-radius: 50%" src="img/image32.png" width="250" height="250"></center>
        <h3><center>Delvin Kurniawan</center></h3>
          <p>
            Saya adalah Mahasiswa aktif Semester 4 di Universitas Bunda Mulia. Disini saya sebagai pembuat dan pengusul design untuk website ini. Berawal dari kecintaanya terhadap seni, saya ingin menghadirkan elemen dekorasi yang siap mempercantik dinding rumah anda.
          </p>
      </div>
    </div>

   <footer>
        <p><center>Kelompok 5 &copy; 2021 All Rights Reserved</center></p>
   </footer>

    <center><a href="https://www.instagram.com" target="blank"><img style="border-radius: 50%" src="image8.png" width="70px" height="50px"></a>
    <a href="https://www.facebook.com" target="blank"><img style="border-radius: 50%" src="image9.png" width="38px" height="38px"></a>
      <a href="https://twitter.com" target="blank"><img style="border-radius: 50%" src="image10.png" width="60px" height="60px"></a>
    </center>

      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.min.js"></script>
      <script src="bootstrap/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js"></script>
    </main>
    <script>
        function highlight(param) {
  
            // Select the whole paragraph
            var ob = new Mark(document.querySelector(".select"));
  
            // First unmark the highlighted word or letter
            ob.unmark();
  
            // Highlight letter or word
            ob.mark(
                document.getElementById("searched").value,
                { className: 'a' + param }
            );
        }
    </script>
  </body>
</html>
